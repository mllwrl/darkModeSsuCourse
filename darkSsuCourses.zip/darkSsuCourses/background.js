// Функция для обновления текста и цвета на иконке
function updateBadge(enabled) {
    // Используем жирную точку для "Вкл" и пустой круг для "Выкл"
    // Или просто пустую строку для "Вкл", чтобы иконка была чистой
    const text = enabled ? " " : "";
    const color = enabled ? "#4CAF50" : "#757575";

    chrome.action.setBadgeText({ text: text });
    chrome.action.setBadgeBackgroundColor({ color: color });
}

// Устанавливаем статус при первом запуске
chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.local.set({ enabled: true }, () => {
        updateBadge(true);
    });
});

// Слушаем клик по иконке
chrome.action.onClicked.addListener((tab) => {
    chrome.storage.local.get("enabled", (data) => {
        const newState = !data.enabled;
        chrome.storage.local.set({ enabled: newState }, () => {
            updateBadge(newState);
            // Сообщаем вкладке, что нужно переключить тему (для мгновенного эффекта)
            chrome.tabs.sendMessage(tab.id, { action: "toggle", enabled: newState }).catch(() => {
                // Ошибка возникнет, если страница еще не загружена — это нормально
            });
        });
    });
});