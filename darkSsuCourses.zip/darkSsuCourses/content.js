function applyTheme(enabled) {
    let styleLink = document.getElementById('ssu-dark-style');

    if (enabled) {
        if (!styleLink) {
            styleLink = document.createElement('link');
            styleLink.id = 'ssu-dark-style';
            styleLink.rel = 'stylesheet';
            styleLink.href = chrome.runtime.getURL('style.css');
            (document.head || document.documentElement).appendChild(styleLink);
        }
    } else {
        if (styleLink) styleLink.remove();
    }
}

// 1. Проверка при загрузке
chrome.storage.local.get("enabled", (data) => {
    applyTheme(data.enabled);
});

// 2. Слушаем мгновенные команды от иконки
chrome.runtime.onMessage.addListener((request) => {
    if (request.action === "toggle") {
        applyTheme(request.enabled);
    }
});